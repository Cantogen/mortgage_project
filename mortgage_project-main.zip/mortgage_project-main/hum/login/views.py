from django.shortcuts import render
from django.http import HttpResponseRedirect
from django import forms
from .forms import CustomerForm

def login_view(request):
        form = CustomerForm()
        return render(request,'login.html',{'form': form})

# Create your views here.
