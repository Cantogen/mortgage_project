# mortgage_project
This is a mortgage project; kinda self explanatory but I can go into detail if needed


	You must run a server and then go to localhost to open this project
	run: python magane.py runserver
	And then open a browser and go to localhost:8000 to see the main page 
	
	~BS 2022-03-18
